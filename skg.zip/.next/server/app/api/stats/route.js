(()=>{var e={};e.id=967,e.ids=[967],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19771:e=>{"use strict";e.exports=require("process")},27910:e=>{"use strict";e.exports=require("stream")},28303:e=>{function t(e){var t=Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}t.keys=()=>[],t.resolve=t,t.id=28303,e.exports=t},28354:e=>{"use strict";e.exports=require("util")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},34631:e=>{"use strict";e.exports=require("tls")},34787:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>_,routeModule:()=>c,serverHooks:()=>x,workAsyncStorage:()=>d,workUnitAsyncStorage:()=>l});var s={};r.r(s),r.d(s,{GET:()=>u});var a=r(96559),o=r(48088),i=r(37719),n=r(32190),p=r(75365);async function u(e){try{let[e]=await p.A.execute("SELECT COUNT(*) as total FROM patients"),[t]=await p.A.execute(`
      SELECT patient_category, COUNT(*) as count 
      FROM patients 
      GROUP BY patient_category
    `),[r]=await p.A.execute(`
      SELECT gender, COUNT(*) as count 
      FROM patients 
      GROUP BY gender
    `),[s]=await p.A.execute(`
      SELECT province, COUNT(*) as count 
      FROM patients 
      WHERE province IS NOT NULL
      GROUP BY province 
      ORDER BY count DESC 
      LIMIT 10
    `),[a]=await p.A.execute(`
      SELECT 
        AVG(dmf_total) as avg_dmf,
        AVG(def_total) as avg_def,
        COUNT(CASE WHEN referral_needed = 1 THEN 1 END) as total_referrals
      FROM clinical_checks
    `),[o]=await p.A.execute(`
      SELECT p.id, p.name, p.exam_id, p.created_at, p.province, p.patient_category
      FROM patients p
      ORDER BY p.created_at DESC
      LIMIT 5
    `);return n.NextResponse.json({success:!0,data:{total_patients:e[0].total,category_distribution:t,gender_distribution:r,top_provinces:s,average_scores:a[0],recent_patients:o}})}catch(e){return console.error("Database error:",e),n.NextResponse.json({success:!1,error:"Failed to fetch statistics"},{status:500})}}let c=new a.AppRouteRouteModule({definition:{kind:o.RouteKind.APP_ROUTE,page:"/api/stats/route",pathname:"/api/stats",filename:"route",bundlePath:"app/api/stats/route"},resolvedPagePath:"C:\\Users\\ASUS\\OneDrive\\Documents\\Firebase\\SKG\\download\\smilesurvey\\src\\app\\api\\stats\\route.ts",nextConfigOutput:"",userland:s}),{workAsyncStorage:d,workUnitAsyncStorage:l,serverHooks:x}=c;function _(){return(0,i.patchFetch)({workAsyncStorage:d,workUnitAsyncStorage:l})}},41204:e=>{"use strict";e.exports=require("string_decoder")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66136:e=>{"use strict";e.exports=require("timers")},74075:e=>{"use strict";e.exports=require("zlib")},75365:(e,t,r)=>{"use strict";r.d(t,{A:()=>s});let s=r(46101).createPool({host:process.env.DB_HOST||"localhost",port:parseInt(process.env.DB_PORT||"3306"),user:process.env.DB_USER||"sql_skg_polkesba",password:process.env.DB_PASSWORD||"pajajaran56",database:process.env.DB_NAME||"sql_skg_polkesba",waitForConnections:!0,connectionLimit:10,queueLimit:0})},78335:()=>{},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[447,263,580,101],()=>r(34787));module.exports=s})();