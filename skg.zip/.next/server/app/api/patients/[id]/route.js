(()=>{var e={};e.id=246,e.ids=[246],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},4809:(e,t,s)=>{"use strict";s.r(t),s.d(t,{patchFetch:()=>E,routeModule:()=>_,serverHooks:()=>m,workAsyncStorage:()=>p,workUnitAsyncStorage:()=>f});var r={};s.r(r),s.d(r,{DELETE:()=>l,GET:()=>d,PUT:()=>u});var a=s(96559),i=s(48088),c=s(37719),o=s(32190),n=s(75365);async function d(e,{params:t}){try{let e=t.id,s=`
      SELECT p.*, c.* 
      FROM patients p 
      LEFT JOIN clinical_checks c ON p.id = c.patient_id 
      WHERE p.id = ?
    `,[r]=await n.A.execute(s,[e]);if(0===r.length)return o.NextResponse.json({success:!1,error:"Patient not found"},{status:404});let a=r[0],i=`
      SELECT * FROM tooth_status 
      WHERE patient_id = ? 
      ORDER BY tooth_number
    `,[c]=await n.A.execute(i,[e]);return o.NextResponse.json({success:!0,data:{...a,tooth_status:c}})}catch(e){return console.error("Database error:",e),o.NextResponse.json({success:!1,error:"Failed to fetch patient"},{status:500})}}async function u(e,{params:t}){try{let s=t.id,r=await e.json(),a=await n.A.getConnection();await a.beginTransaction();try{let e=`
        UPDATE patients SET 
          exam_id = ?, exam_date = ?, province = ?, city = ?, 
          agency = ?, examiner = ?, recorder = ?, patient_category = ?,
          name = ?, village = ?, district = ?, kecamatan = ?, 
          occupation = ?, address = ?, birth_date = ?, gender = ?,
          phone = ?, email = ?, education = ?, school_name = ?,
          class_level = ?, parent_occupation = ?, parent_education = ?,
          verifier_name = ?, verified_at = ?, updated_at = NOW()
        WHERE id = ?
      `,t=[r.exam_id,r.exam_date,r.province,r.city,r.agency,r.examiner,r.recorder,r.patient_category,r.name,r.village,r.district,r.kecamatan,r.occupation,r.address,r.birth_date,r.gender,r.phone,r.email,r.education,r.school_name,r.class_level,r.parent_occupation,r.parent_education,r.verifier_name,r.verified_at,s];if(await a.execute(e,t),r.tooth_status&&Array.isArray(r.tooth_status))for(let e of(await a.execute("DELETE FROM tooth_status WHERE patient_id = ?",[s]),r.tooth_status)){let t=`
            INSERT INTO tooth_status (patient_id, tooth_number, tooth_type, status_code, status_description)
            VALUES (?, ?, ?, ?, ?)
          `;await a.execute(t,[s,e.tooth_number,e.tooth_type,e.status_code,e.status_description])}if(r.clinical_checks){let e=`
          INSERT INTO clinical_checks (
            patient_id, dmf_d, dmf_m, dmf_f, dmf_total,
            def_d, def_e, def_f, def_total, bleeding_gums,
            oral_lesion, calculus, debris, referral_needed, referral_type
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          ON DUPLICATE KEY UPDATE
            dmf_d = VALUES(dmf_d), dmf_m = VALUES(dmf_m), dmf_f = VALUES(dmf_f),
            dmf_total = VALUES(dmf_total), def_d = VALUES(def_d), def_e = VALUES(def_e),
            def_f = VALUES(def_f), def_total = VALUES(def_total),
            bleeding_gums = VALUES(bleeding_gums), oral_lesion = VALUES(oral_lesion),
            calculus = VALUES(calculus), debris = VALUES(debris),
            referral_needed = VALUES(referral_needed), referral_type = VALUES(referral_type),
            updated_at = NOW()
        `,t=[s,r.clinical_checks.dmf_d||0,r.clinical_checks.dmf_m||0,r.clinical_checks.dmf_f||0,r.clinical_checks.dmf_total||0,r.clinical_checks.def_d||0,r.clinical_checks.def_e||0,r.clinical_checks.def_f||0,r.clinical_checks.def_total||0,r.clinical_checks.bleeding_gums||!1,r.clinical_checks.oral_lesion||!1,r.clinical_checks.calculus||!1,r.clinical_checks.debris||!1,r.clinical_checks.referral_needed||!1,r.clinical_checks.referral_type];await a.execute(e,t)}return await a.commit(),a.release(),o.NextResponse.json({success:!0,message:"Patient updated successfully"})}catch(e){throw await a.rollback(),a.release(),e}}catch(e){return console.error("Database error:",e),o.NextResponse.json({success:!1,error:"Failed to update patient"},{status:500})}}async function l(e,{params:t}){try{let e=t.id,[s]=await n.A.execute("DELETE FROM patients WHERE id = ?",[e]);if(0===s.affectedRows)return o.NextResponse.json({success:!1,error:"Patient not found"},{status:404});return o.NextResponse.json({success:!0,message:"Patient deleted successfully"})}catch(e){return console.error("Database error:",e),o.NextResponse.json({success:!1,error:"Failed to delete patient"},{status:500})}}let _=new a.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/api/patients/[id]/route",pathname:"/api/patients/[id]",filename:"route",bundlePath:"app/api/patients/[id]/route"},resolvedPagePath:"C:\\Users\\ASUS\\OneDrive\\Documents\\Firebase\\SKG\\download\\smilesurvey\\src\\app\\api\\patients\\[id]\\route.ts",nextConfigOutput:"",userland:r}),{workAsyncStorage:p,workUnitAsyncStorage:f,serverHooks:m}=_;function E(){return(0,c.patchFetch)({workAsyncStorage:p,workUnitAsyncStorage:f})}},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19771:e=>{"use strict";e.exports=require("process")},27910:e=>{"use strict";e.exports=require("stream")},28303:e=>{function t(e){var t=Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}t.keys=()=>[],t.resolve=t,t.id=28303,e.exports=t},28354:e=>{"use strict";e.exports=require("util")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},34631:e=>{"use strict";e.exports=require("tls")},41204:e=>{"use strict";e.exports=require("string_decoder")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66136:e=>{"use strict";e.exports=require("timers")},74075:e=>{"use strict";e.exports=require("zlib")},75365:(e,t,s)=>{"use strict";s.d(t,{A:()=>r});let r=s(46101).createPool({host:process.env.DB_HOST||"localhost",port:parseInt(process.env.DB_PORT||"3306"),user:process.env.DB_USER||"sql_skg_polkesba",password:process.env.DB_PASSWORD||"pajajaran56",database:process.env.DB_NAME||"sql_skg_polkesba",waitForConnections:!0,connectionLimit:10,queueLimit:0})},78335:()=>{},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),r=t.X(0,[447,263,580,101],()=>s(4809));module.exports=r})();