
import { config } from 'dotenv';
config();

import '@/ai/flows/generate-personalized-tips.ts';
import '@/ai/flows/analyze-dental-data.ts';
